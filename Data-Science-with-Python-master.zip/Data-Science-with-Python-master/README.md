# ItMLwP

This is my collection of scripts for Python (ML), TensorFlow & Keras (DL) for my own learning & reference.
